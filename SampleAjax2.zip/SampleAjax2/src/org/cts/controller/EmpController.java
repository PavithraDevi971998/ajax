package org.cts.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.cts.Patient;
import org.cts.PatientDao;

import com.google.gson.Gson;
@WebServlet("/getDetails")
public class EmpController extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//PatientDao dao=new PatientDao();
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		//PrintWriter pw=response.getWriter();
		//System.out.println(dateInString);
		//pw.println(dateInString);
		SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy");
        String dateInString =request.getParameter("appdate");
        try {
            Date date = formatter.parse(dateInString);
            System.out.println(date);
            System.out.println(formatter.format(date));

        } catch (ParseException e) {
            e.printStackTrace();
        }
        /*PrintWriter pw=response.getWriter();
		List<Patient> emps=dao.getPatient();
		Gson gson=new Gson();
		String jsonRes=gson.toJson(emps);
		System.out.println(jsonRes);
		pw.println(jsonRes);
		pw.close();*/
	}
}
