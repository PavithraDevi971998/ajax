package org.cts;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.cts.Patient;
public class PatientDao {
	
	public List<Patient> getPatient()
	{
		Patient patient=new Patient();
		List<Patient> Patients=new ArrayList<>();
        Connection con=null;
        Statement st=null;
        PreparedStatement pst=null;
        ResultSet rs=null;
        try {
               con=DBUtil.getConnection(DBConstants.DRIVER,DBConstants.URL,DBConstants.UNAME, DBConstants.PWD);
               st=con.createStatement();
              // java.util.Date appdate = new java.util.Date();
              // java.sql.Date sDate = new java.sql.Date(appdate.getTime());
           
               //rs=st.executeQuery("select * from app where appdate='2019-03-11'");
             String selectQuery="select * from app where appdate=sDate";
            // pst=con.prepareStatement(selectQuery);
   			//pst.setString(1, patient.getAppdate());
   			
   		//	rs=pst.executeQuery();
                                        while(rs.next())
                                        {
                                               Patients.add(new Patient(rs.getString(2),rs.getString(3),rs.getString(4),rs.getTime(5)));
                                        }
                                        con.close();
                        } 
                        catch (Exception e) 
                        {
                                        e.printStackTrace();
                        }
                        
                        return Patients;
        }
}

